package com.cqupt.ssm.controller;

import com.cqupt.ssm.entity.Result;
import com.cqupt.ssm.entity.User;
import com.cqupt.ssm.service.UserService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @BelongsProject: test_ssm
 * @BelongsPackage: com.cqupt.ssm.controller
 * @ClassName: UserController
 * @Description: 用户管理控制器
 * @Author: 陈宇鹏
 * @CreateTime: 2023/7/21
 * @Version: 1.0
 **/
@CrossOrigin
@RestController
@RequestMapping("/user")
@Api(tags = "用户管理")
public class UserController {

    @Autowired
    UserService userService;

    @ApiOperation("用户登录")
    @PostMapping("/login")
    public Result login(@RequestBody User user) {
        if (user == null || user.getAccount().length() == 0 || user.getPassword().length() == 0) {
            return Result.failure().message("参数不合理！");
        }
        System.out.println("用户键入信息：" + user);

        User loginResult = userService.getOneByAccountAndPassword(user.getAccount(), user.getPassword());
        if (loginResult != null) {
            System.out.println("查询到用户信息： " + loginResult);
            return Result.success().message("登录成功！");
        }
        return Result.failure().message("用户名或密码不正确！");
    }

}
