package com.cqupt.ssm.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.cqupt.ssm.entity.User;
import com.cqupt.ssm.mapper.UserMapper;
import com.cqupt.ssm.service.UserService;
import org.springframework.stereotype.Service;

/**
 * @BelongsProject: test_ssm
 * @BelongsPackage: com.cqupt.ssm.service.impl
 * @ClassName: UserServiceImpl
 * @Description: 针对表【user】的数据库操作Service实现
 * @Author: 陈宇鹏
 * @CreateTime: 2023/7/21
 * @Version: 1.0
 **/
@Service
public class UserServiceImpl extends ServiceImpl<UserMapper, User> implements UserService {

    @Override
    public User getOneByAccountAndPassword(String account, String password) {
        return baseMapper.getByAccountAndPassword(account, password);
        /*
        QueryWrapper<User> wrapper = new QueryWrapper<User>()
                .eq("account", account)
                .eq("password", password);

        return getOne(wrapper);
        */
    }

}
