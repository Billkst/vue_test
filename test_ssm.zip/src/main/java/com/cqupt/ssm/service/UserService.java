package com.cqupt.ssm.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.cqupt.ssm.entity.User;
import org.springframework.stereotype.Service;

/**
 * @BelongsProject: test_ssm
 * @BelongsPackage: com.cqupt.ssm.service
 * @ClassName: UserService
 * @Description: 针对表【user】的数据库操作Service
 * @Author: 陈宇鹏
 * @CreateTime: 2023/7/21
 * @Version: 1.0
 **/
public interface UserService extends IService<User> {

    public User getOneByAccountAndPassword(String account, String password);

}
