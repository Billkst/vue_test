package com.cqupt.ssm.entity;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

/**
 * @BelongsProject: test_ssm
 * @BelongsPackage: com.cqupt.entity
 * @ClassName: Result
 * @Description: 统一响应结构类
 * @Author: 陈宇鹏
 * @CreateTime: 2023-07-19  09:08
 * @Version: 1.0
 **/
@Data
@ToString
@ApiModel
public class Result {

    @ApiModelProperty(value = "响应状态")
    private boolean status;
    @ApiModelProperty("描述信息")
    private String message;
    @ApiModelProperty("回写数据")
    private Object data;

    static Result result = new Result();

    private static void clearResult() {
        result.message = null;
        result.data = null;
    }

    public static Result success() {
        clearResult();
        result.status = true;
        return result;
    }

    public static Result failure() {
        clearResult();
        result.status = false;
        return result;
    }

    public Result message(String message) {
        result.message = message;
        return result;
    }

    public Result data(Object data) {
        result.data = data;
        return result;
    }

}
