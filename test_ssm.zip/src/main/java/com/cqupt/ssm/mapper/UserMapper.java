package com.cqupt.ssm.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cqupt.ssm.entity.User;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

/**
 * @BelongsProject: test_ssm
 * @BelongsPackage: com.cqupt.ssm.mapper
 * @ClassName: UserMapper
 * @Description: 针对表【user】的数据库操作Mapper
 * @Author: 陈宇鹏
 * @CreateTime: 2023/7/21
 * @Version: 1.0
 **/
public interface UserMapper extends BaseMapper<User> {

    @Select("select * from user where account=#{account} and password=#{password}")
    public User getByAccountAndPassword(@Param("account") String account, @Param("password") String password);

}
