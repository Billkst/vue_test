package com.cqupt.ssm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsmApplicationTests {

    @Test
    void contextLoads() {
    }

}
